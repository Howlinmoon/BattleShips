#!/usr/bin/perl

############################################
##                                        ##
##                 WebBBS                 ##
##           by Darryl Burgdorf           ##
##                                        ##
##           Configuration File           ##
##                                        ##
############################################

## (1) Define the location of your files:

require "/usr/www/userid/cgi-bin/webbbs.pl";
require "/usr/www/userid/cgi-bin/webbbs_text.pl";

$dir = "/usr/userid/board";
$cgiurl = "http://foo.com/cgi-bin/config.pl";

## (2) Tailor the appearance and functionality of your BBS:

$UseLocking = 1;

$bodyspec = "BGCOLOR=\"#ffffff\" TEXT=\"#000000\"";

$messagespec = "";

$NewCode = "<EM><FONT COLOR=\"#990000\">NEW:</FONT></EM> ";

$HeadLinesFile = "";
$HeaderFile = "/usr/userid/board/header.txt";
$FooterFile = "/usr/userid/board/footer.txt";

$MessageHeaderFile = "";
$MessageFooterFile = "";

$UseFrames = "";
$BBSFrame = "_parent";
$WelcomePage = "";

$Admin_Link_Name = "";
$Admin_Link_URL = "";

$SepPostForm = 0;

$DefaultType = "";
$DefaultTime = "";

$boardname = "WebBBS Discussion Board";
$printboardname = 1;

$DateConfig = "";
$IndexEntryLines = 2;

$InputColumns = 80;
$InputRows = 15;

$HourOffset = 0;

$ArchiveOnly = 0;
$AllowHTML = 0;
$SingleLineBreaks = 0;

$AutoQuote = 0;
$AutoQuoteChar = ":";

$AutoHotlink = 0;

$DisplayIPs = 0;
$DisplayViews = 0;

$UseCookies = 1;
require "/usr/www/userid/cgi-bin/cookie.lib";

$Max_Days = 0;
$Max_Messages = 0;

$ArchiveDir = "";

## (3) Define your visitors' capabilities:

$MaxMessageSize = 50;

$MaxInputLength = 50;

$LockRemoteUser = 0;

$AllowUserDeletion = 0;
$AllowEmailNotices = 0;
$AllowPreview = 1;

$AllowURLs = 0;
$AllowPics = 0;

$SaveLinkInfo = 0;

$AllowUserPrefs = 1;
$AllowResponses = 1;

$NaughtyWords = "";
$CensorPosts = 0;

$BannedIPs = "";

## (4) Define your e-mail notification features:

$mailprog = '/usr/sbin/sendmail';
$WEB_SERVER = "";
$SMTP_SERVER = "";

$maillist_address = "webbbs\@foo.com";
$notification_address = "webbbs\@foo.com";
$email_list = 1;
$private_list = 0;

$HeaderOnly = 0;

# use Socket;

&WebBBS;

## (5) If necessary, set up the WebAdverts configuration subroutine

sub insertadvert {
	require "/full/path/to/ads_display.pl";
	$adverts_dir = "/full/path/to/ads";
	$display_cgi = "http://foo.com/ads/ads.pl";
	$advertzone = $_[0];
	$ADVUseLocking = 1;
	$ADVLogIP = 0;
	$DefaultBanner = "";
	$ADVNoPrint = 1;
	&ADVsetup;
}
