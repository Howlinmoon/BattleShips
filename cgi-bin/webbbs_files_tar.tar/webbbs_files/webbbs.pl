############################################
##                                        ##
##                 WebBBS                 ##
##           by Darryl Burgdorf           ##
##       (e-mail burgdorf@awsd.com)       ##
##                                        ##
##             version:  3.20             ##
##        last modified: 10/10/98         ##
##           copyright (c) 1998           ##
##                                        ##
##    latest version is available from    ##
##        http://awsd.com/scripts/        ##
##                                        ##
############################################

# COPYRIGHT NOTICE:
#
# Copyright 1998 Darryl C. Burgdorf.  All Rights Reserved.
#
# This program is being distributed as shareware.  It may be used and
# modified by anyone, so long as this copyright notice and the header
# above remain intact, but any usage should be registered.  (See the
# program documentation for registration information.)  Selling the
# code for this program without prior written consent is expressly
# forbidden.  Obtain permission before redistributing this program
# over the Internet or in any other medium.  In all cases copyright
# and header must remain intact.
#
# This program is distributed "as is" and without warranty of any
# kind, either express or implied.  (Some states do not allow the
# limitation or exclusion of liability for incidental or consequential
# damages, so this notice may not apply to you.)  In no event shall
# the liability of Darryl C. Burgdorf and/or Affordable Web Space
# Design for any damages, losses and/or causes of action exceed the
# total amount paid by the user for this software.

sub WebBBS {
	&Parse_Form;
	&Initialize_Data;
	if ((!($UseFrames) && ($ENV{'QUERY_STRING'} =~ /review=(\d+)/i)) 
	  || ($ENV{'QUERY_STRING'} =~ /read=(\d+)/i)) {
		$messagenumber = $1;
		if ($FORM{'ListType'} =~ /Guestbook-Style, Thread/) {
			&DisplayThread;
		}
		else {
			&DisplayMessage;
		}
	}
	elsif ($ENV{'QUERY_STRING'} =~ /form=(\d+)/i) {
		$messagenumber = $1;
		&PostForm;
	}
	elsif ($ENV{'QUERY_STRING'} =~ /post/i) {
		&PostMessage;
	}
	elsif ($ENV{'QUERY_STRING'} =~ /addresslist/i) {
		&UpdateAddressList;
	}
	elsif ($ENV{'QUERY_STRING'} =~ /subscribe/i) {
		&Subscribe;
	}
	elsif ($ENV{'QUERY_STRING'} =~ /search/i) {
		&Search;
	}
	elsif ($ENV{'QUERY_STRING'} =~ /reconfigure/i) {
		&Reconfigure;
	}
	elsif ($ENV{'QUERY_STRING'} =~ /delete/i) {
		&Delete;
	}
	elsif ($ENV{'QUERY_STRING'} =~ /blank/i) {
		&BlankPage;
	}
	elsif ($UseFrames && ($ENV{'QUERY_STRING'} !~ /index/i)) {
		if ($ENV{'QUERY_STRING'} =~ /review=(\d+)/i) {
			$message = $1;
		}
		&SetupFrames;
	}
	else {
		&DisplayIndex;
	}
}

sub Parse_Form {
	if ($NaughtyWords) {
		@naughtywords = split(/ /,$NaughtyWords);
	}
	read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
	@pairs = split(/&/, $buffer);
	foreach $pair (@pairs){
		($val1, $val2) = split(/=/, $pair);
		$val1 =~ tr/+/ /;
		$val1 =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$val2 =~ tr/+/ /;
		$val2 =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		unless (($AllowHTML > 1) && ($val1 eq "body")) {
			$val2 =~ s/<!--([^>]|\n)*-->/ /g;
		}
		if (($AllowHTML < 1) || ($val1 ne "body")) {
			$val2 =~ s/<([^>]|\n)*>/ /g;
		}
		unless (($AllowHTML eq "1") && ($val1 eq "body")) {
			$val2 =~ s/\&/\&amp\;/g;
			$val2 =~ s/"/\&quot\;/g;
			$val2 =~ s/</\&lt\;/g;
			$val2 =~ s/>/\&gt\;/g;
		}
		if ($val1 eq "body") {
			if ($AutoHotlink) {
				$val2 =~ s/\&amp\;/\&/g;
				$val2 =~ s/([\w]+:\/\/[\w-?&;\.\/]+[\w])/<A HREF="$1">$1<\/A>/g;
			}
			$val2 =~ s/\cM\n*/\n/g;
			$val2 =~ s/\n/<BR>/g;
			$val2 =~ s/<BR>\s\s\s+/<BR><BR>/g;
			$val2 =~ s/<BR>\t/<BR><BR>/g;
			$val2 =~ s/\s+/ /g;
			$val2 =~ s/<BR>\s/<BR>/g;
			$val2 =~ s/\s<BR>/<BR>/g;
			$val2 =~ s/<BR><BR>/<P>/g;
			$val2 =~ s/<P><BR>/<P>/g;
			unless ($SingleLineBreaks) {
				$val2 =~ s/<BR>$AutoQuoteChar/<BRR>/g;
				$val2 =~ s/<BR>&gt;/<BRR>/g;
				$val2 =~ s/<BR>/ /g;
				$val2 =~ s/<BRR>/<BR>$AutoQuoteChar/g;
			}
		}
		else {
			$val2 =~ s/\|/ /g;
		}
		$val2 =~ s/\s+/ /g;
		$val2 =~ s/^\s+//g;
		$val2 =~ s/\s+$//g;
		$val2 =~ s/<P>/\n<P>/g;
		$val2 =~ s/<BR>/\n<BR>/g;
		$val2 =~ s/<P>\n//g;
		$val2 =~ s/<BR>\n//g;
		if ($NaughtyWords) {
			if ($CensorPosts) {
				foreach $naughtyword (@naughtywords) {
					$val2 =~ s/$naughtyword/#####/ig;
				}
			}
			else {
				foreach $naughtyword (@naughtywords) {
					if ($val2 =~ /$naughtyword/) {
						$NaughtyFlag = 1;
					}
				}
			}
		}
		if ($FORM{$val1}) {
			$FORM{$val1} = "$FORM{$val1} $val2";
		}
		else {
			$FORM{$val1} = $val2;
		}
	}
}

sub Initialize_Data {
	$version = "3.20";
	$time = time;
	$todaydate = $time;
	$rebuildflag = 0;
	unless ($InputColumns) { $InputColumns = 80; }
	if ($InputColumns < 25) { $InputColumns = 25; }
	unless ($InputRows) { $InputRows = 15; }
	if ($InputRows < 5) { $InputRows = 5; }
	$InputLength = int($InputColumns/2);
	$TotalMessages = 0;
	$DisplayedMessages = 0;
	@sortedmessages = ();
	@keywordmatches = ();
	$navbar = "";
	if ($ENV{'QUERY_STRING'} =~ /noframes/i) {
		$UseFrames = "";
		$BBSquery = "?noframes&";
	}
	else { $BBSquery = "?"; }
	if ($UseFrames) {
		$BBStarget = " TARGET=msgtxt";
		$BBStargetidx = " TARGET=msgidx";
		$BBStargettop = " TARGET=\"$BBSFrame\"";
		$SepPostForm = 1;
	}
	else {
		$BBStarget = " TARGET=_self";
		$BBStargetidx = " TARGET=_self";
		$BBStargettop = " TARGET=_self";
	}
	if (($ENV{'QUERY_STRING'} =~ /blank/i)
	  || ($UseFrames && !($ENV{'QUERY_STRING'}))) {
		print "Content-type: text/html\n\n";
		return;
	}
	unless (-e "$dir/messages.idx") { &Rebuild_Database; }
	open (INDEX,"$dir/messages.idx") || &Error("9100","9101");
	while (<INDEX>) {
		chop;
		if (($message,$timestamp,$sub,$poster,$date,$prev,$next,$count,$admin,$ip) =
		  split(/\|/)) {
			$TotalMessages ++;
			push (@sortedmessages,$message);
			$timestamp{$message} = $timestamp;
			$age{$message} = (($time-$timestamp)/86400);
			$subject{$message} = $sub;
			$poster{$message} = $poster;
			$date{$message} = $date;
			$previous{$message} = $prev;
			$next{$message} = $next;
			$count{$message} = $count;
			if ($admin eq "AdminPost") {
				$admin{$message} = $admin;
			}
			$ipaddress{$message} = $ip;
			unless (($message =~ /^\d*$/) && ($timestamp =~ /^\d*$/)
			  && ($date =~ /^\d*$/)&& ($prev =~ /^[\d|\s]*$/)
			  && ($next =~ /^[\d|\s]*$/) && ($count =~ /^\d*$/)) {
				$count{$message} = 0;
				&ResetMessageData;
				$rebuildflag = 1;
			}
		}
	}
	close (INDEX);
	$lastmessage = $message;
	opendir (MESSAGES,$dir);
	@messagecount = readdir(MESSAGES);
	closedir (MESSAGES);
	foreach $message (@messagecount) {
		unless (($message =~ /\.tmp$/) || ($message == 0)) {
			if ($message > $lastmessage) {
				$rebuildflag = 1;
			}
		}
	}
	if ($rebuildflag) { &Rebuild_Database; }
	$FORM{'email'} =~ s/\s//g;
	unless ($FORM{'email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|,|;/
	  || $FORM{'email'} !~
	  /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/)
	  {
		$email = "$FORM{'email'}";
	}
	if ($FORM{'name'}) { $name = "$FORM{'name'}"; }
	if ($LockRemoteUser && $ENV{'REMOTE_USER'}) {
		$name = $ENV{'REMOTE_USER'};
	}
	$name = substr($name,0,$MaxInputLength);
	$FORM{'url'} =~ s/\&amp\;/\&/g;
	$FORM{'url'} =~ s/\s//g;
	$FORM{'imageurl'} =~ s/\&amp\;/\&/g;
	$FORM{'imageurl'} =~ s/\s//g;
	unless ($FORM{'url'} =~ /\*|(\.\.)|(^\.)|(\/\/\.)/ ||
	  $FORM{'url'} !~ /.*\:\/\/.*\..*/ ||
	  !($FORM{'url_title'})) {
		$message_url = "$FORM{'url'}";
		$message_url_title = "$FORM{'url_title'}";
	}
	unless ($FORM{'imageurl'} =~ /\*|(\.\.)|(^\.)|(\/\/\.)/ ||
	  $FORM{'imageurl'} !~ /.*\:\/\/.*\..*/) {
		$image_url = "$FORM{'imageurl'}";
	}
	print "Content-type: text/html\n";
	if ($UseCookies) {
		$Cookie_Exp_Date = "Fri, 31-Dec-1999 00:00:00 GMT";
		if ($cgiurl =~ m#^http://([\w-\.]+):?(\d*)/(.+)/#o) {
			$Cookie_Path = "/$3/";
		}
		&GetCompressedCookies($boardname);
		if (!($FORM{'ListType'})) {
			$FORM{'ListType'} = $Cookies{'listtype'};
		}
		if (!($FORM{'ListTime'})) {
			$FORM{'ListTime'} = $Cookies{'listtime'};
		}
		if ($FORM{'KeySearch'} eq "No") {
			$listtype = $FORM{'ListType'};
			$listtime = $FORM{'ListTime'};
		}
		if ($ENV{'QUERY_STRING'} =~ /post/i) {
			if (!($FORM{'wantnotice'})) {
				$Cookies{'wantnotice'} = "no";
			}
			else { $Cookies{'wantnotice'} = "yes"; }
		}
		&Send_Cookie;
	}
	print "\n";
	if (!($FORM{'ListTime'})) { $FORM{'ListTime'} = $DefaultTime; }
	unless ($FORM{'ListTime'}) { $FORM{'ListTime'} = "Week"; }
	if ($ArchiveOnly || ($FORM{'ListTime'} eq "Archive")) {
		$FORM{'ListTime'} = "Several Eons";
	}
	if (!($FORM{'ListType'})) {
		if ($ENV{'HTTP_USER_AGENT'} =~ /Lynx/i ) {
			$FORM{'ListType'} = "Compressed";
		}
		else {
			$FORM{'ListType'} = $DefaultType;
		}
	}
	unless ($FORM{'ListType'}) {
		$FORM{'ListType'} = "Chronologically";
	}
	if ((($FORM{'ListType'} =~ /Guestbook/)
	  || ($FORM{'ListType'} =~ /Compress/))
	  && ($IndexEntryLines eq "news")) {
		$IndexEntryLines = 2;
	}
	$maillist_link = "<A HREF=\"mailto:$maillist_address\">";
	$maillist_link .= "$maillist_address<\/A>";
	foreach $key (keys %text) {
		$text{$key} =~ s/<!--boardname-->/$boardname/g;
		$text{$key} =~ s/<!--boardurl-->/$cgiurl/g;
		$text{$key} =~ s/<!--email-->/$maillist_address/g;
		$text{$key} =~ s/<!--emaillink-->/$maillist_link/g;
		$text{$key} =~ s/<!--NoFramesURL-->/<A HREF="$cgiurl?noframes">/g;
	}
	unless ($DateConfig) {
		$DateConfig = "%DY%, %dy% %MO% %YR%, at %hr%:%mn% %am%";
	}
	unless ($NewCode) {
		$NewCode = "<EM><FONT COLOR=\"#990000\">NEW:</FONT></EM> ";
	}
	unless ($AutoQuoteChar) {
		$AutoQuoteChar = ":";
	}
}

sub SetupFrames {
	print "<HTML><HEAD><TITLE>$boardname</TITLE>\n";
	if ($HeadLinesFile) {
		open (HEADLN,"$HeadLinesFile");
		@headln = <HEADLN>;
		close (HEADLN);
		foreach $line (@headln) {
			print "$line";
		}
	}
	print "</HEAD>\n";
	if ($UseFrames =~ /h/i) {
		print "<FRAMESET ROWS=\"50%,*\" BORDER=1>\n";
	}
	else {
		print "<FRAMESET COLS=\"33%,*\" BORDER=1>\n";
	}
	print "<FRAME NAME=\"msgidx\" SCROLLING=auto ";
	print "SRC=\"$cgiurl?index\">\n";
	print "<FRAME NAME=\"msgtxt\" SCROLLING=auto ";
	if ($message) {
		print "SRC=\"$cgiurl?read=$message\">\n";
	}
	elsif ($WelcomePage) {
		print "SRC=\"$WelcomePage\">\n";
	}
	else {
		print "SRC=\"$cgiurl?blank\">\n";
	}
	print "<NOFRAME>\n";
	print "<BODY $bodyspec>\n";
	if ($HeaderFile) {
		open (HEADER,"$HeaderFile");
		@header = <HEADER>;
		close (HEADER);
		foreach $line (@header) {
			if ($line =~ /<!--InsertAdvert\s*(.*)-->/i) {
				&insertadvert($1);
			}
			else {
				print "$line";
			}
		}
	}
	if ($printboardname) {
		print "<P ALIGN=CENTER>";
		print "<BIG><STRONG>$boardname</STRONG></BIG></P>\n";
	}
	print "$text{'0100'}\n";
	print "<P ALIGN=CENTER><SMALL><EM>$boardname ";
	print "is maintained with <STRONG>";
	print "<A HREF=\"http://awsd.com/scripts/webbbs/\" TARGET=_top>";
	print "WebBBS $version</A></STRONG>.</EM></SMALL></P>\n";
	if ($FooterFile) {
		open (FOOTER,"$FooterFile");
		@footer = <FOOTER>;
		close (FOOTER);
		foreach $line (@footer) {
			if ($line =~ /<!--InsertAdvert\s*(.*)-->/i) {
				&insertadvert($1);
			}
			else {
				print "$line";
			}
		}
	}
	print "</BODY></NOFRAME></FRAMESET></HTML>\n";
	reset 'A-Za-z';
	exit;
}

sub BlankPage {
	print "<HTML><BODY $bodyspec>\n";
	print "</BODY></HTML>\n";
	reset 'A-Za-z';
	exit;
}

sub PrintDate {
	unless ($_[0] =~ /^\d*$/) {
		return $_[0];
	}
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) =
	  localtime($_[0]+($HourOffset*3600));
	if ($sec < 10) { $sec = "0$sec"; }
	if ($min < 10) { $min = "0$min"; }
	$hour24 = $hour;
	if ($hour24 < 10) { $hour24 = "0$hour24"; }
	$ampm = "a.m.";
	if ($hour eq 12) { $ampm = "p.m."; }
	if ($hour eq 0) { $hour = "12"; }
	if ($hour > 12) { $hour = ($hour - 12); $ampm = "p.m."; }
	$month = $months[$mon];
	$mon ++;
	$yearlong = $year+1900;
	if ($year > 99) { $year = $year-100; }
	$wday = $days[$wday];
	$datestring = $DateConfig;
	$datestring =~ s/%mo%/$mon/g;
	$datestring =~ s/%MO%/$month/g;
	$datestring =~ s/%dy%/$mday/g;
	$datestring =~ s/%DY%/$wday/g;
	$datestring =~ s/%yr%/$year/g;
	$datestring =~ s/%YR%/$yearlong/g;
	$datestring =~ s/%am%/$ampm/g;
	$datestring =~ s/%sc%/$sec/g;
	$datestring =~ s/%mn%/$min/g;
	$datestring =~ s/%hr%/$hour/g;
	$datestring =~ s/%HR%/$hour24/g;
	return $datestring;
}

sub DisplayMessage {
	foreach $message (@sortedmessages) {
		if ($message < $messagenumber) {
			$prevmessage = $message;
		}
		elsif ($message > $messagenumber) {
			$nextmessage = $message;
			last;
		}
	}
	open (FILE,"$dir/$messagenumber") || &Error("9100","9101");
	@message = <FILE>;
	close (FILE);
	$count{$messagenumber}++;
	if ($DisplayViews) {
		&Rebuild_Database;
	}
	$admin = "";
	($subject,$poster,$email,$date,$image_url,$linkname,$linkurl) = "";
	foreach $line (@message) {
		if ($line =~ /^SUBJECT>(.*)/i) { $subject = $1; }
		elsif ($line =~ /^ADMIN>AdminPost/i) { $admin = "AdminPost"; }
		elsif ($line =~ /^ADMIN>/i) { next; }
		elsif ($line =~ /^POSTER>(.*)/i) { $poster = $1; }
		elsif ($line =~ /^EMAIL>(.*)/i) { $email = $1; }
		elsif ($line =~ /^DATE>(.*)/i) { $date = $1; }
		elsif ($line =~ /^EMAILNOTICES>/i) { next; }
		elsif ($line =~ /^IP_ADDRESS>(.*)/i) { $ipaddress = $1; }
		elsif ($line =~ /^PASSWORD>(.*)/i) { $oldpassword = $1; }
		elsif ($line =~ /^PREVIOUS>(.*)/i) { $previous = $1; }
		elsif ($line =~ /^NEXT>(.*)/i) { $next = $1; }
		elsif ($line =~ /^IMAGE>(.*)/i) { $image_url = $1; }
		elsif ($line =~ /^LINKNAME>(.*)/i) { $linkname = $1; }
		elsif ($line =~ /^LINKURL>(.*)/i) { $linkurl = $1; }
		elsif (!$startup) {
			$startup = 1;
			&Header($subject,$MessageHeaderFile);
			unless (((($FORM{'ListType'} =~ /Chrono/)
			  || ($previous == 0)) && ($next == 0))
			  && ($prevmessage == 0) && ($nextmessage == 0)
			  && ($ArchiveOnly || (!($AllowResponses))) && ($UseFrames)) {
				$navbar .= "<P><CENTER>";
				$navbar .= "<TABLE BORDER CELLPADDING=6>";
				$navbar .= "<TR><TH>|";
				unless ((($FORM{'ListType'} =~ /Chrono/)
				  || ($previous == 0)) && ($next == 0)) {
					$navbar .= " <A HREF=\"#Responses\">";
					if ($FORM{'ListType'} =~ /Chrono/) {
						$navbar .= "$text{'0001'}</A> |";
					}
					else {
						$navbar .= "$text{'0002'}</A> |";
					}
				}
				unless ($ArchiveOnly || (!($AllowResponses))) {
					if ($SepPostForm) {
						$navbar .= " <A HREF=\"$cgiurl$BBSquery";
						$navbar .= "form=$messagenumber\"";
						$navbar .= "$BBStargettop>";
					}
					else {
						$navbar .= " <A HREF=\"#PostResponse\">";
					}
					$navbar .= "$text{'0003'}</A> |";
				}
				unless ($UseFrames) {
					$navbar .= " <A HREF=\"$cgiurl$BBSquery\" ";
					$navbar .= "TARGET=_self>";
					$navbar .= "$text{'0004'}</A> |";
				}
				if ($prevmessage > 0) {
					$navbar .= " <A HREF=\"$cgiurl$BBSquery";
					$navbar .= "read=$prevmessage\"$BBStarget>";
					$navbar .= "$text{'0005'}</A> |";
				}
				if ($nextmessage > 0) {
					$navbar .= " <A HREF=\"$cgiurl$BBSquery";
					$navbar .= "read=$nextmessage\"$BBStarget>";
					$navbar .= "$text{'0006'}</A> |";
				}
				$navbar .= "</TH></TR></TABLE></CENTER></P>\n";
				print "$navbar";
			}
			unless ($UseFrames) {
				if ($printboardname) {
					print "<P ALIGN=CENTER><BIG><STRONG>";
					print "$boardname</STRONG></BIG></P>\n";
				}
			}
			print "<H1 ALIGN=CENTER>";
			print "$subject</H1>\n";
			print "<P ALIGN=CENTER><STRONG>";
			print "Posted By: <BIG>$poster</BIG>";
			if ($email) {
				print " &lt;<A HREF=\"mailto:$email\">$email</A>&gt;";
			}
			if ($DisplayIPs && $ipaddress) {
				print " <SMALL><EM>($ipaddress)</EM></SMALL>\n";
			}
			print "<BR>Date: ",&PrintDate($date),"\n";
			if ($subject{$previous}) {
				print "<P ALIGN=CENTER><EM>In Response To: ";
				print "<A HREF=\"$cgiurl$BBSquery";
				print "read=$previous\"$BBStarget>";
				print "$subject{$previous}</A> ";
				print "($poster{$previous})</EM>\n";
			}
			print "</STRONG></P><FONT $messagespec>\n";
			print $line;
		}
		else { print $line; }
	}
	print "</FONT></P>\n";
	if ($image_url) {
		print "<P ALIGN=CENTER>";
		print "<IMG SRC=\"$image_url\"></P>\n";
	}
	if ($linkurl) {
		print "<P ALIGN=CENTER>";
		print "<EM><A HREF=\"$linkurl\" ";
		print "TARGET=_top>";
		print "$linkname</A></EM></P>\n";
	}
	unless ((($FORM{'ListType'} =~ /Chrono/)
	  || ($previous == 0))
	  && ($next == 0)) {
		print "<H2 ALIGN=CENTER>";
		print "<A NAME=\"Responses\">";
		@responses = split(/ /,$next);
		$responsecount = 0;
		if ($FORM{'ListType'} =~ /Chrono/) {
			print "Responses To This Message</A></H2>\n";
			if ($IndexEntryLines eq "news") {
				print "<P><CENTER><TABLE>\n";
			}
			else {
				print "<P><UL>";
			}
			if ($FORM{'ListType'} =~ /Reversed/) {
				@sortedresponses = reverse(@responses);
			}
			else {
				@sortedresponses = @responses;
			}
			foreach $response (@sortedresponses) {
				if ($subject{$response}) {
					&PrintMessageDesc($response);
					$responsecount ++;
				}
			}
			if ($IndexEntryLines eq "news") {
				print "</TABLE></CENTER></P>\n";
			}
			else {
				print "</UL></P>\n";
			}
			if ($responsecount eq 0) {
				print "<P ALIGN=CENTER>";
				print "(There are no responses ";
				print "to this message.)</P>\n";
			}
		}
		else {
			print "Messages in This Thread</A></H2>\n";
			if ($IndexEntryLines eq "news") {
				print "<P><CENTER><TABLE>\n";
			}
			else {
				print "<P><UL>";
			}
			&FindStart($messagenumber);
			&ThreadList($threadstart);
			if ($IndexEntryLines eq "news") {
				print "</TABLE></CENTER></P>\n";
			}
			else {
				print "</UL></P>\n";
			}
		}
	}
	unless (($ArchiveOnly || (!($AllowResponses))) || $SepPostForm) {
		print "<H2 ALIGN=CENTER>";
		print "<A NAME=\"PostResponse\">";
		print "Post a Response</A></H2>\n";
		&Print_Form($messagenumber);
	}
	if ($AllowUserDeletion) {
		$PrintDeleteButton = 1;
	}
	&Footer($MessageFooterFile,"credits");
}

sub DisplayThread {
	&FindStart($messagenumber);
	&Header($subject,$MessageHeaderFile);
	unless (($ArchiveOnly || (!($AllowResponses))) && ($UseFrames)) {
		$navbar .= "<P><CENTER>";
		$navbar .= "<TABLE BORDER CELLPADDING=6>";
		$navbar .= "<TR><TH>|";
		unless ($ArchiveOnly || (!($AllowResponses))) {
			if ($SepPostForm) {
				$navbar .= " <A HREF=\"$cgiurl$BBSquery";
				$navbar .= "form=$threadstart\"";
				$navbar .= "$BBStargettop>";
			}
			else {
				$navbar .= " <A HREF=\"#PostResponse\">";
			}
			$navbar .= "$text{'0003'}</A> |";
		}
		unless ($UseFrames) {
			$navbar .= " <A HREF=\"$cgiurl$BBSquery\" TARGET=_self>";
			$navbar .= "$text{'0004'}</A> |";
		}
		$navbar .= "</TH></TR></TABLE></CENTER></P>\n";
		print "$navbar";
	}
	unless ($UseFrames) {
		if ($printboardname) {
			print "<P ALIGN=CENTER><BIG><STRONG>";
			print "$boardname</STRONG></BIG></P>\n";
		}
	}
	@guestbookthread = ();
	&ThreadGuestbook($threadstart);
	@sortedguestbookthread = sort (@guestbookthread);
	if ($FORM{'ListType'} =~ /Reversed/) {
		@guestbookthread = reverse(@sortedguestbookthread);
		@sortedguestbookthread = @guestbookthread;
	}
	print "<H1 ALIGN=CENTER>";
	print "$subject{$threadstart}</H1>\n";
	foreach $message (@sortedguestbookthread) {
		&PrintGuestbookDesc($message);
	}
	unless (($ArchiveOnly || (!($AllowResponses))) || $SepPostForm) {
		print "<H2 ALIGN=CENTER>";
		print "<A NAME=\"PostResponse\">";
		print "Post a Response</A></H2>\n";
		&Print_Form($threadstart);
	}
	if ($DisplayViews) {
		&Rebuild_Database;
	}
	&Footer($MessageFooterFile,"credits");
}

sub FindStart {
	$threadstart = $_[0];
	if ($previous{$threadstart}) {
		if ($subject{$previous{$threadstart}}) {
			&FindStart($previous{$threadstart});
		}
	}
}

sub Delete {
	$PassCheck = 0;
	unless ($FORM{'newpassword'}) { &Error("9600","9601"); }
	$newpassword = crypt($FORM{'newpassword'},"aa");
	$message = $FORM{'delete'};
	unless (-e "$dir/$message") { &Error("9600","9601"); }
	$oldpassword = "";
	open (FILE,"$dir/$message");
	@message = <FILE>;
	close (FILE);
	foreach $line (@message) {
		if ($line =~ /^PASSWORD>(.*)/i) {
			$oldpassword = $1;
			last;
		}
	}
	if ($oldpassword) {
		if ($newpassword eq $oldpassword) {
			$PassCheck = 1;
		}
	}
	unless ($PassCheck == 1) {
		unless (-e "$dir/password.txt") {
			&Error("9600","9601");
		}
		open (PASSWORD, "$dir/password.txt");
		$password = <PASSWORD>;
		close (PASSWORD);
		chop ($password) if ($password =~ /\n$/);
		unless ($newpassword eq $password) {
			&Error("9600","9601");
		}
	}
	unlink "$dir/$message";
	&Rebuild_Database;
	&Header("Message(s) Deleted!",$MessageHeaderFile);
	&Header2;
	print "$text{'0200'}\n";
	&Footer($MessageFooterFile,"return");
}

sub PrintMessageDesc {
	if ($IndexEntryLines eq "news") {
		print "<TR><TD>$indexspacer";
		if ($Cookies{'lastmessage'}
		  && ($Cookies{'lastmessage'} < $_[0])) {
			print "$NewCode";
		}
		unless ($messagenumber == $_[0]) {
			print "<A HREF=\"$cgiurl$BBSquery";
			print "read=$_[0]\"$BBStarget>";
		}
		print "$subject{$_[0]}";
		unless ($messagenumber == $_[0]) {
			print "</A>";
		}
		if (($count{$_[0]} > 0) && $DisplayViews) {
			print " <SMALL>(views: $count{$_[0]})</SMALL>";
		}
		print "</TD><TD>";
		print "$poster{$_[0]} ";
		if ($DisplayIPs && $ipaddress{$_[0]}) {
			print " <SMALL><EM>($ipaddress{$_[0]})</EM></SMALL> ";
		}
		print "</TD><TD>",&PrintDate($date{$_[0]});
		print "</TD></TR>\n";
	}
	else {
		if ($admin{$_[0]}) {
			print "<BIG><STRONG>\n";
		}
		print "<LI><STRONG>";
		if ($Cookies{'lastmessage'}
		  && ($Cookies{'lastmessage'} < $_[0])) {
			print "$NewCode";
		}
		unless ($messagenumber == $_[0]) {
			print "<A HREF=\"$cgiurl$BBSquery";
			print "read=$_[0]\"$BBStarget>";
		}
		print "$subject{$_[0]}";
		unless ($messagenumber == $_[0]) {
			print "</A>";
		}
		print "</STRONG>";
		if (($count{$_[0]} > 0) && $DisplayViews) {
			print " <SMALL>(views: $count{$_[0]})</SMALL>";
		}
		if ($IndexEntryLines == 1) {
			print " -- ";
		}
		else {
			print "<BR>";
		}
		print "$poster{$_[0]} ";
		if ($DisplayIPs && $ipaddress{$_[0]}) {
			print " <SMALL><EM>($ipaddress{$_[0]})</EM></SMALL> ";
		}
		print "-- ",&PrintDate($date{$_[0]});
		if ($admin{$_[0]}) {
			print "</STRONG></BIG>";
		}
		print "\n";
	}
}

sub PrintGuestbookDesc {
	$messagenumber = $_[0];
	$count{$messagenumber}++;
	open (FILE,"$dir/$messagenumber") || return;
	@message = <FILE>;
	close (FILE);
	$startup = 0;
	$admin = "";
	($subject,$poster,$email,$date,$image_url,$linkname,$linkurl) = "";
	foreach $line (@message) {
		if ($line =~ /^SUBJECT>(.*)/i) { $subject = $1; }
		elsif ($line =~ /^ADMIN>AdminPost/i) { $admin = "AdminPost"; }
		elsif ($line =~ /^ADMIN>/i) { next; }
		elsif ($line =~ /^POSTER>(.*)/i) { $poster = $1; }
		elsif ($line =~ /^EMAIL>(.*)/i) { $email = $1; }
		elsif ($line =~ /^DATE>(.*)/i) { $date = $1; }
		elsif ($line =~ /^EMAILNOTICES>/i) { next; }
		elsif ($line =~ /^IP_ADDRESS>(.*)/i) { $ipaddress = $1; }
		elsif ($line =~ /^PASSWORD>(.*)/i) { $oldpassword = $1; }
		elsif ($line =~ /^PREVIOUS>(.*)/i) { $previous = $1; }
		elsif ($line =~ /^NEXT>(.*)/i) { $next = $1; }
		elsif ($line =~ /^IMAGE>(.*)/i) { $image_url = $1; }
		elsif ($line =~ /^LINKNAME>(.*)/i) { $linkname = $1; }
		elsif ($line =~ /^LINKURL>(.*)/i) { $linkurl = $1; }
		elsif (!$startup) {
			$startup = 1;
			print "<P ALIGN=CENTER>";
			print "<STRONG><BIG>";
			if ($Cookies{'lastmessage'}
			  && ($Cookies{'lastmessage'} < $messagenumber)) {
				print "$NewCode";
			}
			print "$subject";
			print "</BIG></STRONG>";
			print "<BR>";
			if ($email) {
				print "<A HREF=\"mailto:$email\">$poster</A>";
			}
			else { print "$poster"; }
			if ($DisplayIPs && $ipaddress{$_[0]}) {
				print " <SMALL><EM>($ipaddress{$_[0]})</EM></SMALL> ";
			}
			print " -- <EM>",&PrintDate($date),"</EM></P><FONT $messagespec>\n";
			print $line;
		}
		else { print $line; }
	}
	print "</FONT></P>\n";
	if ($image_url) {
		print "<P ALIGN=CENTER>";
		print "<IMG SRC=\"$image_url\"></P>\n";
	}
	if ($linkurl) {
		print "<P ALIGN=CENTER>";
		print "<EM><A HREF=\"$linkurl\" ";
		print "TARGET=_top>";
		print "$linkname</A></EM></P>\n";
	}
}

sub PostForm {
	if ($messagenumber > 1) {
		&Header("$text{'0003'}",$MessageHeaderFile);
	}
	else {
		&Header("$text{'0007'}",$MessageHeaderFile);
	}
	$navbar .= "<P><CENTER>";
	$navbar .= "<TABLE BORDER CELLPADDING=6>";
	$navbar .= "<TR><TH>| <A HREF=\"$cgiurl$BBSquery\" $BBStargettop>";
	$navbar .= "$text{'0004'}</A> |";
	$navbar .= "</TH></TR></TABLE></CENTER></P>\n";
	print "$navbar";
	if ($printboardname) {
		print "<P ALIGN=CENTER><BIG><STRONG>";
		print "$boardname</STRONG></BIG></P>\n";
	}
	print "<H1 ALIGN=CENTER>";
	if ($messagenumber > 1) {
		print "$text{'0003'}</H1>\n";
		open (FILE,"$dir/$messagenumber");
		@message = <FILE>;
		close (FILE);
		&Print_Form($messagenumber);
	}
	else {
		print "$text{'0007'}</H1>\n";
		&Print_Form;
	}
	&Footer($MessageFooterFile,"credits");
}

sub Print_Form {
	if ($ArchiveOnly || ($_[0] && !($AllowResponses))) {
		return;
	}
	print "<P><FORM METHOD=POST ACTION=\"$cgiurl$BBSquery";
	print "post\" TARGET=_self>\n";
	if ($_[0]) {
		print "<INPUT TYPE=HIDDEN NAME=\"followup\" ";
		print "VALUE=\"$_[0]\">\n";
	}
	print "<P><CENTER><TABLE><TR>\n";
	print "<TD ALIGN=RIGHT><P><STRONG>Your Name:</STRONG>";
	if ($LockRemoteUser && $ENV{'REMOTE_USER'}) {
		print "</TD><TD><INPUT TYPE=HIDDEN NAME=\"name\" ";
		print " VALUE=\"$ENV{'REMOTE_USER'}\">";
		print "<STRONG>$ENV{'REMOTE_USER'}</STRONG>";
		print "</TD></TR><TR>\n";
	}
	else {
		print "</TD><TD><INPUT TYPE=TEXT NAME=\"name\" ";
		print "SIZE=$InputLength MAXLENGTH=$MaxInputLength";
		if ($Cookies{'name'}) {
			print " VALUE=\"$Cookies{'name'}\"";
		}
		print "></TD></TR><TR>\n";
	}
	print "<TD ALIGN=RIGHT><P><STRONG>E-Mail Address:</STRONG>";
	print "</TD><TD><INPUT TYPE=TEXT NAME=\"email\" ";
	print "SIZE=$InputLength MAXLENGTH=$MaxInputLength";
	if ($Cookies{'email'}) {
		print " VALUE=\"$Cookies{'email'}\"";
	}
	print "></TD></TR><TR>\n";
	print "<TD ALIGN=RIGHT><P><STRONG>Subject:</STRONG>";
	print "</TD><TD><INPUT TYPE=TEXT NAME=\"subject\" ";
	print "SIZE=$InputLength MAXLENGTH=$MaxInputLength";
	if ($_[0]) {
		print " VALUE=\"";
		unless ($subject{$_[0]} =~ /^Re:/) { print "Re: "; }
		print "$subject{$_[0]}\"";
	}
	print "></TD></TR><TR>\n";
	print "<TD COLSPAN=2 ALIGN=CENTER>";
	print "<P><STRONG>Message:</STRONG>\n";
	print "<BR><TEXTAREA COLS=$InputColumns ROWS=$InputRows ";
	print "NAME=\"body\" WRAP=VIRTUAL>";
	if ($_[0] && $AutoQuote
	  && ($FORM{'ListType'} !~ /Guestbook-Style, Thread/)) {
		$quotedtext = "";
		foreach $line (@message) {
			unless (($line =~ /^SUBJECT>/i)
			  || ($line =~ /^ADMIN>/i)
			  || ($line =~ /^POSTER>/i)
			  || ($line =~ /^EMAIL>/i)
			  || ($line =~ /^DATE>/i)
			  || ($line =~ /^EMAILNOTICES>/i)
			  || ($line =~ /^IP_ADDRESS>/i)
			  || ($line =~ /^PASSWORD>/i)
			  || ($line =~ /^PREVIOUS>/i)
			  || ($line =~ /^NEXT>/i)
			  || ($line =~ /^IMAGE>/i)
			  || ($line =~ /^LINKNAME>/i)
			  || ($line =~ /^LINKURL>/i)
			  || ($line =~ /^<([^>])*>&gt;/i)
			  || ($line =~ /^<([^>])*>$AutoQuoteChar/i)
			  || ($line =~ /^<([^>])*>$/i)) {
				$quotedtext .= $line;
			}
		}
		$quotedtext =~ s/\n/ /g;
		$quotedtext =~ s/<P>/\n\n$AutoQuoteChar /g;
		$quotedtext =~ s/<BR>/\n$AutoQuoteChar /g;
		$quotedtext =~ s/$AutoQuoteChar\s*\n*$AutoQuoteChar /$AutoQuoteChar /g;
		$quotedtext =~ s/^\n*//g;
		$quotedtext =~ s/<([^>]|\n)*>/ /g;
		$quotedtext =~ s/\& /\&amp\; /g;
		$quotedtext =~ s/"/\&quot\;/g;
		$quotedtext =~ s/</\&lt\;/g;
		$quotedtext =~ s/>/\&gt\;/g;
		@quotedlines = split(/\n/,$quotedtext);
		foreach $quotedline (@quotedlines) {
			$quotewrap = 0;
			@quotedwords = split(/\s/,$quotedline);
			foreach $quotedword (@quotedwords) {
				$quotewrap += length($quotedword)+1;
				if ($quotewrap > $InputColumns) {
					print "\n$AutoQuoteChar $quotedword ";
					$quotewrap = length($quotedword)+6;
				}
				else {
					print "$quotedword ";
				}
			}
			print "\n";
		}
	}
	print "</TEXTAREA></TD></TR><TR>\n";
	if ($AllowURLs) {
		print "<TD COLSPAN=2 ALIGN=CENTER>";
		print "$text{'1500'}";
		print "</TD></TR><TR>\n";
		print "<TD ALIGN=RIGHT><P><STRONG>";
		print "Optional Link URL:</STRONG></TD>";
		print "<TD><INPUT TYPE=TEXT ";
		print "NAME=\"url\" SIZE=$InputLength";
		if ($Cookies{'linkurl'}) {
			print " VALUE=\"$Cookies{'linkurl'}\"";
		}
		else {
			print " VALUE=\"http://\"";
		}
		print "></TD></TR><TR>\n";
		print "<TD ALIGN=RIGHT><P><STRONG>";
		print "Optional Link Title:</STRONG></TD>";
		print "<TD><INPUT TYPE=TEXT ";
		print "NAME=\"url_title\" SIZE=$InputLength";
		if ($Cookies{'linkname'}) {
			print " VALUE=\"$Cookies{'linkname'}\"";
		}
		print "></TD></TR><TR>\n";
	}
	if ($AllowPics) {
		print "<TD COLSPAN=2 ALIGN=CENTER>";
		print "$text{'1501'}";
		print "</TD></TR><TR>\n";
		print "<TD ALIGN=RIGHT><P><STRONG>";
		print "Optional Image URL:</STRONG></TD>";
		print "<TD><INPUT TYPE=TEXT ";
		print "NAME=\"imageurl\" SIZE=$InputLength";
		if ($Cookies{'imageurl'}) {
			print " VALUE=\"$Cookies{'imageurl'}\"";
		}
		else {
			print " VALUE=\"http://\"";
		}
		print "></TD></TR><TR>\n";
	}
	if ($AllowUserDeletion && ($FORM{'ListType'} !~ /Guestbook/)) {
		print "<TD COLSPAN=2 ALIGN=CENTER>";
		print "$text{'1502'}";
		print "</TD></TR><TR>\n";
		print "<TD ALIGN=RIGHT><P><STRONG>";
		print "Password:</STRONG></TD>";
		print "<TD><INPUT TYPE=PASSWORD NAME=\"password\" ";
		print "SIZE=$InputLength></TD></TR><TR>\n";
	}
	if ($mailprog && $AllowEmailNotices) {
		print "<TD COLSPAN=2 ALIGN=CENTER>";
		print "$text{'1503'} ";
		print "<INPUT TYPE=CHECKBOX NAME=\"wantnotice\"";
		unless ($Cookies{'wantnotice'} eq "no") {
			print " CHECKED";
		}
		print " VALUE=\"yes\"></TD></TR><TR>\n";
	}
	print "<TH COLSPAN=2><P>";
	if ($AllowPreview) {
		print "<INPUT TYPE=SUBMIT NAME=\"Preview\" ";
		print "VALUE=\"Preview Message\"> ";
	}
	print "<INPUT TYPE=SUBMIT NAME=\"Post\" ";
	print "VALUE=\"Post Message\"></TH>";
	print "</TR></TABLE></CENTER></P></FORM>\n";
}

sub DisplayIndex {
	&Header("$boardname - Message Index",$HeaderFile);
	$navbar .= "<P><CENTER>";
	$navbar .= "<TABLE BORDER CELLPADDING=6>";
	$navbar .= "<TR><TH>|";
	unless ($ArchiveOnly) {
		if ($SepPostForm) {
			$navbar .= " <A HREF=\"$cgiurl$BBSquery";
			$navbar .= "form=0\"";
			$navbar .= "$BBStargettop>";
		}
		else {
			$navbar .= " <A HREF=\"#PostMessage\">";
		}
		$navbar .= "$text{'0007'}</A> |";
	}
	if ($mailprog && $email_list && !($private_list)) {
		$navbar .= " <A HREF=\"$cgiurl$BBSquery";
		$navbar .= "subscribe\"$BBStarget> $text{'0008'}</A> |";
	}
	unless ($FORM{'KeySearch'}) {
		$FORM{'KeySearch'} = "No";
	}
	if ($FORM{'KeySearch'} ne "No") {
		$navbar .= " <A HREF=\"$cgiurl$BBSquery\" ";
		$navbar .= "$BBStargettop>";
		$navbar .= "$text{'0004'}</A> |";
	}
	$navbar .= " <A HREF=\"$cgiurl$BBSquery";
	$navbar .= "search\"$BBStarget>$text{'0009'}</A> |";
	if ($AllowUserPrefs) {
		$navbar .= " <A HREF=\"$cgiurl$BBSquery";
		$navbar .= "reconfigure\"$BBStarget>$text{'0010'}</A> |";
	}
	if ($Admin_Link_Name && $Admin_Link_URL) {
		$navbar .= " <A HREF=\"$Admin_Link_URL\"$BBStarget>";
		$navbar .= "$Admin_Link_Name</A> |";
	}
	$navbar .= "</TH></TR></TABLE></CENTER></P>\n";
	print "$navbar";
	if ($printboardname) {
		print "<P ALIGN=CENTER><BIG><STRONG>";
		print "$boardname</STRONG></BIG></P>\n";
	}
	print "<H1 ALIGN=CENTER>Message Index</H1>\n";
	if ($FORM{'KeySearch'} ne "No") {
		$FORM{'ListType'} = "Chronologically, Reversed";
		print "<P ALIGN=CENTER><STRONG>";
		print "Search Results</STRONG></P>\n";
	}
	elsif ($Cookies{'lastvisit'}) {
		print "<P ALIGN=CENTER><STRONG>Welcome back";
		if ($Cookies{'name'}) { print ", $Cookies{'name'}"; }
		print "!<EM><BR>Your last visit began ";
		print &PrintDate($Cookies{'lastvisit'}),"</EM>\n";
		if ($Cookies{'lastmessage'} < $lastmessage) {
			$NewCount = 0;
			$startcount = $Cookies{'lastmessage'}+1;
			foreach $messagecount ($startcount..$lastmessage) {
				if (-e "$dir/$messagecount") { $NewCount++; }
			}
			print "<BR>Since then, $NewCount new message";
			if ($NewCount > 1) { print "s have"; }
			else { print " has"; }
		}
		else {
			print "<BR>Since then, no new messages have";
		}
		print " been posted!</STRONG></P>\n";
	}
	elsif ($Cookies{'lastmessage'}) {
		print "<P ALIGN=CENTER><STRONG>Welcome";
		if ($Cookies{'name'}) { print ", $Cookies{'name'}"; }
		print "!\n";
		if ($Cookies{'lastmessage'} < $lastmessage) {
			$NewCount = $lastmessage - $Cookies{'lastmessage'};
			print "<BR>$NewCount new message";
			if ($NewCount > 1) { print "s have"; }
			else { print " has"; }
			print " been posted!";
		}
		print "</STRONG></P>\n";
	}
	else {
		print "<P ALIGN=CENTER><STRONG>";
		print "Welcome!</STRONG></P>\n";
	}
	if ($FORM{'ListTime'} eq "Twelve Hours") { $startday = .5; }
	elsif ($FORM{'ListTime'} eq "Day") { $startday = 1; }
	elsif ($FORM{'ListTime'} eq "Two Days") { $startday = 2; }
	elsif ($FORM{'ListTime'} eq "Week") { $startday = 7; }
	elsif ($FORM{'ListTime'} eq "Two Weeks") { $startday = 14; }
	elsif ($FORM{'ListTime'} eq "Month") { $startday = 30; }
	else { $startday = 10000; }
	if ($ArchiveOnly || ($startday eq 10000)) {
		if ($FORM{'KeySearch'} eq "No") {
			print "<P ALIGN=CENTER>All Messages\n";
		}
		else {
			print "<P ALIGN=CENTER>Messages of Any Age\n";
		}
	}
	else {
		print "<P ALIGN=CENTER>Messages Posted or Modified ";
		print "Within the Last $FORM{'ListTime'}\n";
	}
	if ($FORM{'KeySearch'} eq "Yes") {
		$FORM{'Keywords'} =~ s/\"/ /g;
		@keywords = split(/\s+/, $FORM{'Keywords'});
		print "<P ALIGN=CENTER>Containing ";
		print "<STRONG>$FORM{'Boolean'}</STRONG> ";
		print "of the Keywords:<BR>";
		foreach $keyword (@keywords) {
			print "<STRONG>$keyword</STRONG>";
			$i++;
			if (!($i == @keywords)) { print ", "; }
			else { print "\n"; }
		}
		foreach $message (@sortedmessages) {
			if ($age{$message} <= $startday) {
				open (FILE,"$dir/$message");
				@LINES = <FILE>;
				close (FILE);
				$string = join(' ',@LINES);
				$string =~ s/\n//g;
				$value = 0;
				if ($FORM{'Boolean'} eq 'All') {
					foreach $term (@keywords) {
						$test = ($string =~ s/$term//ig);
						if ($test < 1) {
							$value = 0;
							last;
						}
						else {
							$value = $value+$test;
						}
					}
				}
				elsif ($FORM{'Boolean'} eq 'Any') {
					foreach $term (@keywords) {
						$test = ($string =~ s/$term//ig);
						$value = $value+$test;
					}
				}
				if ($value > 0) {
					push (@keywordmatches, $message);
				}
				else {
					$DontUse{$message} = 1;
				}
			}
			else {
				$DontUse{$message} = 1;
			}
		}
		@sortedmessages = @keywordmatches;
	}
	elsif ($FORM{'KeySearch'} eq "Author") {
		print "<P ALIGN=CENTER>Posted By ";
		print "<STRONG>&quot;$FORM{'Author'}&quot;</STRONG>\n";
		foreach $message (@sortedmessages) {
			if ($age{$message} <= $startday) {
				$value = 0;
				if ($poster{$message} =~ /$FORM{'Author'}/i) {
					push (@keywordmatches, $message);
				}
				else {
					$DontUse{$message} = 1;
				}
			}
			else {
				$DontUse{$message} = 1;
			}
		}
		@sortedmessages = @keywordmatches;
	}
	foreach $message (@sortedmessages) {
		if ($age{$message} <= $startday) {
			if ($subject{$message}) {
				$DisplayedMessages ++;
			}
			else {
				$DontUse{$message} = 1;
			}
		}
		else {
			$DontUse{$message} = 1;
		}
	}
	print "<P ALIGN=CENTER><EM>";
	unless (($FORM{'ListType'} =~ /Compress/)
	  || ($FORM{'ListType'} =~ /Guestbook-Style, Thread/)) {
		print "$DisplayedMessages of ";
		print "$TotalMessages Messages Displayed<BR>";
	}
	if ($FORM{'KeySearch'} eq "No") {
		if ($FORM{'ListType'} eq "Chronologically") {
			print "(Chronological Listing)";
		}
		elsif ($FORM{'ListType'} eq "Chronologically, Reversed") {
			print "(Reversed Chronological Listing)";
		}
		elsif ($FORM{'ListType'} eq "Compressed") {
			print "(Compressed Listing)";
		}
		elsif ($FORM{'ListType'} eq "Compressed, Reversed") {
			print "(Reversed Compressed Listing)";
		}
		elsif ($FORM{'ListType'} eq "Guestbook-Style") {
			print "(Guestbook-Style Listing)";
		}
		elsif ($FORM{'ListType'} eq "Guestbook-Style, Reversed") {
			print "(Reversed Guestbook-Style Listing)";
		}
		elsif ($FORM{'ListType'} eq "Guestbook-Style, Threaded") {
			print "(Threaded Guestbook-Style Listing)";
		}
		elsif ($FORM{'ListType'} eq "Guestbook-Style, Threaded, Reversed") {
			print "(Reversed Threaded Guestbook-Style Listing)";
		}
		elsif ($FORM{'ListType'} eq "By Threads, Reversed") {
			print "(Reversed Threaded Listing)";
		}
		elsif ($FORM{'ListType'} eq "By Threads, Mixed") {
			print "(Mixed Threaded Listing)";
		}
		else { print "(Threaded Listing)"; }
	}
	print "</EM></P>\n";
	$messagecount = 0;
	unless (($FORM{'ListType'} =~ /Guestbook/)
	  && ($FORM{'ListType'} !~ /Threaded/)) {
		if ($IndexEntryLines eq "news") {
			print "<P><CENTER><TABLE>\n";
		}
		else {
			print "<P><UL>\n";
		}
	}
	if (($FORM{'ListType'} =~ /Compress/)
	  || ($FORM{'ListType'} =~ /Guestbook-Style, Thread/)) {
		@messages = ();
		foreach $message (@sortedmessages) {
			if ($subject{$message} && !($already{$message})) {
				$respcount = -1;
				$showthread = 0;
				$newcount = 0;
				if ($Cookies{'lastmessage'}
				  && ($Cookies{'lastmessage'} < $message)) {
					$newcount--;
				}
				&CompressList($message);
				if ($showthread > 0) {
					push (@messages,$message);
					$messagecount ++;
					$respcount{$message} = $respcount;
					$newcount{$message} = $newcount;
				}
			}
		}
		if ($FORM{'ListType'} =~ /Reversed/) {
			@sortedmessages = reverse(@messages);
		}
		else {
			@sortedmessages = @messages;
		}
		foreach $message (@sortedmessages) {
			&PrintMessageDesc($message);
			print "<BR><STRONG>$respcount{$message} response";
			unless ($respcount{$message} == 1) {
				print "s";
			}
			if ($newcount{$message} > 0) {
				print " ($newcount{$message} new)";
			}
			print "</STRONG>\n";
		}
	}
	elsif (($FORM{'ListType'} =~ /Chrono/)
	  || ($FORM{'ListType'} =~ /Guestbook/)) {
		if ($FORM{'ListType'} =~ /Reversed/) {
			@messages = reverse(@sortedmessages);
		}
		else {
			@messages = @sortedmessages;
		}
		foreach $message (@messages) {
			if ($subject{$message} && !($DontUse{$message})) {
				if ($FORM{'ListType'} =~ /Guestbook/) {
					&PrintGuestbookDesc($message);
				}
				else {
					&PrintMessageDesc($message);
				}
				$messagecount ++;
			}
		}
	}
	elsif ($FORM{'ListType'} eq "By Threads") {
		foreach $message (@sortedmessages) {
			if ($subject{$message} && !($already{$message})
			  && !($DontUse{$message})) {
				&ThreadList($message);
				$messagecount ++;
			}
		}
	}
	else {
		@reversedmessages = reverse(@sortedmessages);
		foreach $message (@reversedmessages) {
			if ($subject{$message} && !($already{$message})
			  && !($DontUse{$message})) {
				unless ($subject{$previous{$message}}
				  && !($DontUse{$previous{$message}})) {
					&ThreadList($message);
					$messagecount ++;
				}
			}
		}
	}
	unless (($FORM{'ListType'} =~ /Guestbook/)
	  && ($FORM{'ListType'} !~ /Threaded/)) {
		if ($IndexEntryLines eq "news") {
			print "</TABLE></CENTER></P>\n";
		}
		else {
			print "</UL></P>\n";
		}
	}
	if ($messagecount < 1) {
		print "<P ALIGN=CENTER><STRONG>No messages ";
		print "matched your search criteria! ";
		print "Please try again....</STRONG></P>\n";
	}
	unless ($ArchiveOnly || $SepPostForm) {
		print "<H2 ALIGN=CENTER>";
		print "<A NAME=\"PostMessage\">";
		print "Post a New Message</A></H2>\n";
		&Print_Form;
	}
	if ($DisplayViews) {
		if (($FORM{'ListType'} =~ /Guestbook/)
		  && ($FORM{'ListType'} !~ /Threaded/)) {
			&Rebuild_Database;
		}
	}
	&Footer($FooterFile,"credits");
}

sub Subscribe {
	&Header("Subscribe / Unsubscribe",$MessageHeaderFile);
	&Header2;
	print "<H1 ALIGN=CENTER>";
	print "Subscribe / Unsubscribe</H1>\n";
	print "<P>If you'd like to, you may receive ";
	if ($email_list == 1) {
		print "automatic e-mail notifications ";
	}
	else {
		print "regular e-mail digests ";
	}
	print "of all new posts! ";
	print "(If you're already on the list, and would like to be removed, ";
	print "you may also use this form to unsubscribe.) ";
	print "Simply provide your e-mail address below\n";
	print "<FORM METHOD=POST ACTION=\"$cgiurl$BBSquery";
	print "addresslist\"$BBStarget>\n";
	print "<P><CENTER>Your E-Mail Address: ";
	print "<INPUT TYPE=TEXT NAME=\"email\" SIZE=30";
	if ($Cookies{'email'}) {
		print " VALUE=\"$Cookies{'email'}\"";
	}
	print "> <INPUT TYPE=SUBMIT VALUE=\"Send Address\">\n";
	print "<BR><INPUT TYPE=RADIO NAME=\"action\" ";
	print "VALUE=\"add\" CHECKED> Add Address to List ";
	print "<INPUT TYPE=RADIO NAME=\"action\" ";
	print "VALUE=\"delete\"> Delete Address from List";
	print "</CENTER></P></FORM>\n";
	&Footer($MessageFooterFile,"credits");
}

sub CompressList {
	local (@threadresponses);
	$respcount++;
	unless ($DontUse{$_[0]}) { $showthread = 1; }
	if ($Cookies{'lastmessage'}
	  && ($Cookies{'lastmessage'} < $_[0])) {
		$newcount++;
	}
	@threadresponses = split(/ /,$next{$_[0]});
	foreach $threadresponse (@threadresponses) {
		next unless ($threadresponse > $_[0]);
		if ($subject{$threadresponse}) {
			&CompressList($threadresponse);
		}
	}
	$already{$_[0]} = 1;
}

sub ThreadList {
	local (@threadresponses);
	local (@reversethread);
	&PrintMessageDesc($_[0]);
	if ($IndexEntryLines eq "news") {
		$indexspacer .= " &nbsp; &nbsp; &nbsp;";
	}
	else {
		print "<UL>\n";
	}
	@threadresponses = split(/ /,$next{$_[0]});
	if ($FORM{'ListType'} eq "By Threads, Reversed") {
		@reversethread = reverse(@threadresponses);
		@threadresponses = @reversethread;
	}
	foreach $threadresponse (@threadresponses) {
		next unless ($threadresponse > $_[0]);
		if ($subject{$threadresponse}
		  && !($DontUse{$threadresponse})) {
			&ThreadList($threadresponse);
		}
	}
	if ($IndexEntryLines eq "news") {
		$indexspacer =~ s/ &nbsp; &nbsp; &nbsp;$//;
	}
	else {
		print "</UL>\n";
	}
	$already{$_[0]} = 1;
}

sub ThreadGuestbook {
	local (@threadresponses);
	push (@guestbookthread,$_[0]);
	@threadresponses = split(/ /,$next{$_[0]});
	foreach $threadresponse (@threadresponses) {
		next unless ($threadresponse > $_[0]);
		if ($subject{$threadresponse}) {
			&ThreadGuestbook($threadresponse);
		}
	}
}

sub PostMessage {
	if ($DisplayIPs == 1) {
		if (($ENV{'REMOTE_ADDR'} =~ /\d+\.\d+\.\d+\.\d+/)
		  && (!($ENV{'REMOTE_HOST'})
		  || ($ENV{'REMOTE_HOST'} =~ /\d+\.\d+\.\d+\.\d+/))) {
			@domainbytes = split(/\./,$ENV{'REMOTE_ADDR'});
			$packaddr = pack("C4",@domainbytes);
			$resolvedip = (gethostbyaddr($packaddr, 2))[0];
			if ($resolvedip) {
				$ENV{'REMOTE_HOST'} = $resolvedip;
			}
		}
	}
	if ($ArchiveOnly || ($FORM{'followup'} && !($AllowResponses))) {
		&Error("9520","9521");
	}
	if ($BannedIPs) {
		@bannedips = split(/ /,$BannedIPs);
		foreach $bannedip (@bannedips) {
			if ($ENV{'REMOTE_HOST'} =~ /$bannedip/i) {
				&Error("9520","9521");
			}
			if ($ENV{'REMOTE_ADDR'} =~ /$bannedip/i) {
				&Error("9520","9521");
			}
		}
	}
	if ($NaughtyFlag) {
		&Error("9510","9511");
	}
	if ($FORM{'PrevConfirm'}) {
		$num = $FORM{'PrevConfirm'};
		rename ("$dir/$num.tmp","$dir/$num");
		open (FILE,"$dir/$num") || &Error("9100","9101");
		@message = <FILE>;
		close (FILE);
		foreach $line (@message) {
			if ($line =~ /^SUBJECT>(.*)/i) {
				$FORM{'subject'} = $1;
				$subject = $FORM{'subject'};
			}
			elsif ($line =~ /^POSTER>(.*)/i) {
				$FORM{'name'} = $1;
				$name = $FORM{'name'};
			}
			elsif ($line =~ /^EMAIL>(.*)/i) { $email = $1; }
			elsif ($line =~ /^DATE>(.*)/i) { $todaydate = $1; }
			elsif ($line =~ /^PREVIOUS>(.*)/i) { $followup = $1; }
			unless (($line =~ /^SUBJECT>/i)
			  || ($line =~ /^ADMIN>/i)
			  || ($line =~ /^POSTER>/i)
			  || ($line =~ /^EMAIL>/i)
			  || ($line =~ /^DATE>/i)
			  || ($line =~ /^EMAILNOTICES>/i)
			  || ($line =~ /^IP_ADDRESS>/i)
			  || ($line =~ /^PASSWORD>/i)
			  || ($line =~ /^PREVIOUS>/i)
			  || ($line =~ /^NEXT>/i)
			  || ($line =~ /^IMAGE>/i)
			  || ($line =~ /^LINKNAME>/i)
			  || ($line =~ /^LINKURL>/i)) {
				$FORM{'body'} = $FORM{'body'} . $line;
			}
		}
		&PublishPost;
	}
	if ($FORM{'followup'}) { $followup = "$FORM{'followup'}"; }
	if ($FORM{'subject'}) { $subject = "$FORM{'subject'}"; }
	if ($FORM{'body'}) { $body = "$FORM{'body'}"; }
	$subject = substr($subject,0,$MaxInputLength);
	unless ($name && $subject && $body) {
		&Error("9200","9201");
	}
	if (length($body) > ($MaxMessageSize*1024)) {
		&Error("9250","9251");
	}
	$new_body =
	  $name.$email.$subject.$body.$image_url.$message_url_title.$message_url;
	$new_body =~ s/\n/ /g;
	unless (-w "$dir") { &Error("9400","9401"); }
	open (DUPEDATA,"$dir/dupecheck.txt");
	$last_body = <DUPEDATA>;
	close (DUPEDATA);
	if ($last_body eq $new_body) { &Error("9500","9501"); }
	else {
		open (DUPEDATA,">$dir/dupecheck.txt");
		print DUPEDATA "$new_body";
		close (DUPEDATA);
	}
	unless (-e "$dir/data.txt") {
		open (NUMBER,">$dir/data.txt");
		print NUMBER "0";
		close (NUMBER);
	}
	&LockOpen (NUMBER,"$dir/data.txt");
	$num = <NUMBER>;
	$num++;
	seek (NUMBER, 0, 0);
	print NUMBER "$num";
	truncate (NUMBER, tell(NUMBER));
	&LockClose (NUMBER,"$dir/data.txt");
	if ($FORM{'Preview'}) {
		open (MESSAGE,">$dir/$num.tmp")
		  || &Error("9400","9401");
	}
	else {
		open (MESSAGE,">$dir/$num")
		  || &Error("9400","9401");
	}
	print MESSAGE "SUBJECT>$subject\n";
	print MESSAGE "POSTER>$name\n";
	print MESSAGE "EMAIL>$email\n";
	print MESSAGE "DATE>$todaydate\n";
	if (!($FORM{'wantnotice'})) {
		print MESSAGE "EMAILNOTICES>no\n";
	}
	print MESSAGE "IP_ADDRESS>";
	if ($DisplayIPs == 2) {
		print MESSAGE "$ENV{'REMOTE_ADDR'}\n";
	}
	else {
		if ($ENV{'REMOTE_HOST'}) {
			print MESSAGE "$ENV{'REMOTE_HOST'}\n";
		}
		else {
			print MESSAGE "$ENV{'REMOTE_ADDR'}\n";
		}
	}
	if ($FORM{'password'}) {
		$password = crypt($FORM{'password'},"aa");
		print MESSAGE "PASSWORD>$password\n";
	}
	print MESSAGE "PREVIOUS>$followup\n";
	print MESSAGE "NEXT>\n";
	print MESSAGE "IMAGE>$image_url\n";
	print MESSAGE "LINKNAME>$message_url_title\n";
	print MESSAGE "LINKURL>$message_url\n";
	print MESSAGE "<P>$body\n";
	close (MESSAGE);
	if ($FORM{'Preview'}) {
		&Header("Message Preview",$MessageHeaderFile);
		print "$text{'2000'}\n";
		print "<P><CENTER><FORM METHOD=POST ";
		print "ACTION=\"$cgiurl$BBSquery";
		print "post\" TARGET=_self>\n";
		print "<INPUT TYPE=HIDDEN NAME=PrevConfirm VALUE=$num>\n";
		print "<INPUT TYPE=SUBMIT VALUE=\"Post Message\">\n";
		print "</FORM></CENTER></P>\n";
		print "<H1 ALIGN=CENTER>";
		print "$subject</H1>\n";
		print "<P ALIGN=CENTER><STRONG>";
		print "Posted By: <BIG>$name</BIG>";
		if ($email) {
			print " &lt;<A HREF=\"mailto:$email\">$email</A>&gt;";
		}
		print "\n";
		print "<BR>Date: ",&PrintDate($todaydate),"\n";
		if ($subject{$followup}) {
			print "<P ALIGN=CENTER><EM>In Response To: ";
			print "<A HREF=\"$cgiurl$BBSquery";
			print "read=$followup\"$BBStarget>";
			print "$subject{$followup}</A> ";
			print "($poster{$followup})</EM>\n";
		}
		print "</STRONG></P><FONT $messagespec>\n";
		print "<P>$body</P></FONT>\n";
		if ($image_url) {
			print "<P ALIGN=CENTER>";
			print "<IMG SRC=\"$image_url\"></P>\n";
		}
		if ($message_url) {
			print "<P ALIGN=CENTER>";
			print "<EM><A HREF=\"$message_url\" ";
			print "TARGET=_top>";
			print "$message_url_title</A></EM></P>\n";
		}
		&Footer($MessageFooterFile,"credits");
	}
	&PublishPost;
}

sub PublishPost {
	if ($followup) {
		open (FOLLOWUP,"$dir/$followup");
		@followup_lines = <FOLLOWUP>;
		close (FOLLOWUP);
		open (FOLLOWUP,">$dir/$followup");
		foreach $line (@followup_lines) {
			chop $line;
			if ($line =~ /^EMAILNOTICES>/i) {
				$wantnotice{$followup} = "no";
			}
			if ($line =~ /^EMAIL>(.*)/i) {
				$email{$followup} = $1;
			}
			if ($line =~ /^DATE>/) {
				print FOLLOWUP "DATE>$date{$followup}\n";
			}
			elsif ($line =~ /^NEXT>/) {
				print FOLLOWUP "$line $num\n";
			}
			else {
				print FOLLOWUP "$line\n";
			}
		}
		close (FOLLOWUP);
		$timestamp{$followup} = $time;
		$next{$followup} .= " $num";
	}
	if ($mailprog) {
		$FORM{'subject'} = &UnWebify($FORM{'subject'});
		$FORM{'subject'} = substr($FORM{'subject'},0,50);
		$FORM{'name'} = &UnWebify($FORM{'name'});
		$FORM{'name'} = substr($FORM{'name'},0,15);
		$FORM{'body'} .= "\n";
		$FORM{'body'} = &UnWebify($FORM{'body'});
		$message_url_title = &UnWebify($message_url_title);
		$body = $text{'7000'}."\n\n".$text{'7001'}."\n\n";
		$body .= "   MESSAGE:   (#$num) $FORM{'subject'}\n";
		$body .= "              <$cgiurl?review=$num>\n";
		$body .= "   AUTHOR:    $FORM{'name'}";
		if ($email) {
			$body .= " <$email>";
		}
		$body .= "\n";
		$body .= "   DATE:      ";
		$body .= &PrintDate($todaydate)."\n\n";
		if ($followup) {
			$subjectfu = &UnWebify($subject{$followup});
			$subjectfu = substr($subjectfu,0,50);
			$posterfu = &UnWebify($poster{$followup});
			$posterfu = substr($posterfu,0,15);
			$body .= "   Reply To:  (#$followup) $subjectfu\n";
			$body .= "   Author:    $posterfu\n";
			$body .= "   Date:      ";
			$body .= &PrintDate($date{$followup})."\n\n";
		}
		unless ($HeaderOnly) {
			$body .= $FORM{'body'}."\n";
			if ($message_url && $message_url_title) {
				$body .= "   Link:      $message_url_title\n";
				$body .= "   URL:       <$message_url>\n\n";
			}
		}
		$body .= $text{'7001'}."\n\n".$text{'7002'};
		unless ($ArchiveOnly) {
			$body .= "  ".$text{'7003'};
		}
		$body .= "\n\n";
		@bodylines = split(/\n/,$body);
		$body = "";
		foreach $bodyline (@bodylines) {
			if ($bodyline =~ /^\./) {
				$bodyline = ".".$bodyline;
			}
			$quotewrap = 0;
			@quotedwords = split(/\s/,$bodyline);
			foreach $quotedword (@quotedwords) {
				$quotewrap += length($quotedword)+1;
				if ($quotewrap > 79) {
					if ($quotedword =~ /^\./) {
						$body .= "\n.$quotedword ";
					}
					else {
						$body .= "\n$quotedword ";
					}
					$quotewrap = length($quotedword)+1;
				}
				else {
					$body .= "$quotedword ";
				}
			}
			$body .= "\n";
		}
		$bcc = "";
		if (($email_list == 1) || $private_list) {
			if (-e "$dir/addresses.txt") {
				open (ADDRESSES,"$dir/addresses.txt");
				@addresses = <ADDRESSES>;
				close (ADDRESSES);
				foreach $address (@addresses) {
					chop $address;
					unless (($address =~
					  /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|,|;/
					  || $address !~
					  /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,3}|[0-9]{1,3})(\]?)$/)
					  || ($email && ($address =~ /$email/i))
					  || ($email{$followup}
					  && ($address =~ /$email{$followup}/i))) {
						$bcc .= ", ".$address;
					}
					if ($email{$followup}
					  && ($address =~ /$email{$followup}/i)) {
						$onrecipientlist = 1;
					}
				}
				$bcc =~ s/^, //;
			}
			&SendMail;
		}
		if ($email{$followup}) {
			$bcc = "";
			unless ((($wantnotice{$followup} eq "no")
			  && !$onrecipientlist)
			  || ($email{$followup} eq $email)) {
				&SendMail($email{$followup});
			}
		}
	}
	if ($AllowPreview || ($Max_Days > 0) || ($Max_Messages > 0)) {
		opendir (FILES,$dir);
		@files = readdir(FILES);
		closedir (FILES);
	}
	if ($AllowPreview) {
		foreach $file (@files) {
			if (((-M "$dir/$file") > .1) && ($file =~ /\.tmp$/)) {
				unlink ("$dir/$file");
			}
		}
	}
	if ($Max_Days > 0) {
		foreach $file (@files) {
			if (((-M "$dir/$file") > $Max_Days) && ($file > 0)) {
				if ($ArchiveDir) {
					rename ("$dir/$file","$ArchiveDir/$file");
				}
				else {
					unlink ("$dir/$file");
				}
			}
		}
	}
	if ($Max_Messages > 0) {
		@sortedfiles = sort {$b<=>$a} @files;
		$Message_Count = 0;
		foreach $file (@sortedfiles) {
			if (($file > 0) && ($file !~ /\.tmp$/)) {
				$Message_Count++;
				if ($Message_Count > $Max_Messages) {
					if ($ArchiveDir) {
						rename ("$dir/$file",
						  "$ArchiveDir/$file");
					}
					else {
						unlink ("$dir/$file");
					}
				}
			}
		}
	}
	&Rebuild_Database;
	&Header("Message Posted",$MessageHeaderFile);
	$navbar .= "<P><CENTER>";
	$navbar .= "<TABLE BORDER CELLPADDING=6>";
	$navbar .= "<TR><TH>|";
	if ($UseFrames) {
		$navbar .= " <A HREF=\"$cgiurl$BBSquery";
		$navbar .= "review=$num\" TARGET=_self>$text{'0004'} / ";
		$navbar .= "$text{'0011'}</A> |";
	}
	else {
		$navbar .= " <A HREF=\"$cgiurl$BBSquery";
		$navbar .= "read=$num\" TARGET=_self>$text{'0011'}</A> |";
		$navbar .= " <A HREF=\"$cgiurl$BBSquery\" ";
		$navbar .= "TARGET=_self>$text{'0004'}</A> |";
	}
	$navbar .= "</TH></TR></TABLE></CENTER></P>\n";
	print "$navbar";
	if ($printboardname) {
		print "<P ALIGN=CENTER><BIG><STRONG>";
		print "$boardname</STRONG></BIG></P>\n";
	}
	print "<H1 ALIGN=CENTER>";
	print "Message Posted</H1>\n";
	print "<P ALIGN=CENTER>Thanks for contributing!</P>\n";
	&Footer($MessageFooterFile,"return");
}

sub UnWebify {
	$texttoconvert = $_[0];
	$texttoconvert =~ s/<P>/\n\n/g;
	$texttoconvert =~ s/<([^>]|\n)*>//g;
	$texttoconvert =~ s/\&quot\;/"/g;
	$texttoconvert =~ s/\&lt\;/</g;
	$texttoconvert =~ s/\&gt\;/>/g;
	$texttoconvert =~ s/\&amp\;/\&/g;
	$texttoconvert =~ s/\n(\n)+/\n\n/g;
	$texttoconvert =~ s/^\n*//g;
	$texttoconvert =~ s/\n+$/\n/g;
	return $texttoconvert;
}

sub SendMail {
	local($To) = $_[0];
	unless ($To) { $To = $notification_address; }
	return unless $To;
	unless ($mailprog eq "SMTP") {
		open (MAIL, "|$mailprog -t") || &Error("9450","9451");
		print MAIL "To: $To\n";
		if ($bcc) {
			print MAIL "Bcc: $bcc\n";
		}
		print MAIL "From: $maillist_address\n",
		  "Return-Path: $maillist_address\n",
		  "Reply-To: PleaseRespond\@TheBulletinBoard\n",
		  "Subject: [$boardname] $FORM{'subject'}\n\n",
		  "$body";
		close (MAIL);
		return;
	}
	unless ($WEB_SERVER) {
		$WEB_SERVER = $ENV{'SERVER_NAME'};
	}
	if (!$WEB_SERVER) {
		&Error("9450","9451");
	}
	unless ($SMTP_SERVER) {
		$SMTP_SERVER = "smtp.$WEB_SERVER";
		$SMTP_SERVER =~ s/^smtp\.[^.]+\.([^.]+\.)/smtp.$1/;
	}
	local($AF_INET) = ($] > 5 ? AF_INET : 2);
	local($SOCK_STREAM) = ($] > 5 ? SOCK_STREAM : 1);
	$, = ', ';
	$" = ', ';
	local($local_address) = (gethostbyname($WEB_SERVER))[4];
	local($local_socket_address) = pack('S n a4 x8', $AF_INET, 0, $local_address);
	local($server_address) = (gethostbyname($SMTP_SERVER))[4];
	local($server_socket_address) = pack('S n a4 x8', $AF_INET, '25', $server_address);
	local($protocol) = (getprotobyname('tcp'))[2];
	if (!socket(SMTP, $AF_INET, $SOCK_STREAM, $protocol)) {
		&Error("9450","9451");
	}
	bind(SMTP, $local_socket_address);
	if (!(connect(SMTP, $server_socket_address))) {
		&Error("9450","9451");
	}
	local($old_selected) = select(SMTP); 
	$| = 1; 
	select($old_selected);
	$* = 1;
	select(undef, undef, undef, .75);
	sysread(SMTP, $_, 1024);
	print SMTP "HELO $WEB_SERVER\r\n";
	sysread(SMTP, $_, 1024);
	while (/(^|(\r?\n))[^0-9]*((\d\d\d).*)$/g) {
		$status = $4;
		$message = $3;
	}
	if ($status != 250) {
		&Error("9450","9451");
	}
	print SMTP "MAIL FROM:<$from>\r\n";
	sysread(SMTP, $_, 1024);
	if (!/[^0-9]*250/) {
		&Error("9450","9451");
	}
	local($good_addresses) = 0;
	$To = "<$To>";
	print SMTP "RCPT TO:$To\r\n";
	sysread(SMTP, $_, 1024);
	/[^0-9]*(\d\d\d)/;
	if ($1 eq '250') {
		$good_addresses++;
	}
	if ($bcc) {
		local(@bcc) = split(/, */, $bcc);
		foreach $address (@bcc) {
			if ($address) {
				$address = "<$address>";
				print SMTP "RCPT TO:$address$CRLF";
				sysread(SMTP, $_, 1024);
				/[^0-9]*(\d\d\d)/;
				if ($1 eq '250') {
					$good_addresses++;
				}
			}
		}
	}
	if (!$good_addresses) {
		&Error("9450","9451");
	}
	print SMTP "DATA\r\n";
	sysread(SMTP, $_, 1024);
	if (!/[^0-9]*354/) {
		&Error("9450","9451");
	}
	print SMTP "To: $To\r\n";
	print SMTP "From: $maillist_address\r\n";
	print SMTP "Return-Path: $maillist_address\r\n";
	print SMTP "Reply-To: PleaseRespond\@TheBulletinBoard\r\n";
	print SMTP "Subject: [$boardname:] $FORM{'subject'}\r\n\r\n";
	print SMTP "$body";
	print SMTP "\r\n\r\n.\r\n";
	sysread(SMTP, $_, 1024);
	shutdown(SMTP, 2);
}

sub Send_Cookie {
	unless (($ENV{'QUERY_STRING'} =~ /post/i) 
	  && !($FORM{'PrevConfirm'})) {
		if (!$name) { $name = $Cookies{'name'}; }
		if (!$email) { $email = $Cookies{'email'}; }
		if (!$message_url) { $message_url = $Cookies{'linkurl'}; }
		if (!$message_url_title) { $message_url_title = $Cookies{'linkname'}; }
		if (!$image_url) {$image_url = $Cookies{'imageurl'}; }
	}
	if (!$listtype) { $listtype = $Cookies{'listtype'}; }
	if (!$listtime) { $listtime = $Cookies{'listtime'}; }
	if (!($Cookies{'thisvisit'})) {
		$Cookies{'thisvisit'} = $Cookies{'lastvisit'};
	}
	if (!($Cookies{'thismessage'})) {
		$Cookies{'thismessage'} = $Cookies{'lastmessage'};
	}
	if (($time - $Cookies{'timestamp'}) < 1800) {
		$lastvisit = $Cookies{'lastvisit'};
		$lastseen = $Cookies{'lastmessage'};
		$thisvisit = $Cookies{'thisvisit'};
		$thisseen = $Cookies{'thismessage'};
	}
	else {
		$lastvisit = $Cookies{'thisvisit'};
		$lastseen = $Cookies{'thismessage'};
		$Cookies{'lastvisit'} = $Cookies{'thisvisit'};
		$Cookies{'lastmessage'} = $Cookies{'thismessage'};
		$thisvisit = $todaydate;
		$thisseen = $lastmessage;
	}
	if (!($Cookies{'lastmessage'})) {
		$Cookies{'lastmessage'} = $lastmessage;
	}
	if ($SaveLinkInfo) {
		&SetCompressedCookies($boardname,'name',$name,'email',$email,
		  'listtype',$listtype,'listtime',$listtime,
		  'lastmessage',$lastseen,'lastvisit',$lastvisit,
		  'thismessage',$thisseen,'thisvisit',$thisvisit,
		  'timestamp',$time,'wantnotice',$Cookies{'wantnotice'},
		  'linkurl',$message_url,'linkname',$message_url_title,
		  'imageurl',$image_url);
	}
	else {
		&SetCompressedCookies($boardname,'name',$name,'email',$email,
		  'listtype',$listtype,'listtime',$listtime,
		  'lastmessage',$lastseen,'lastvisit',$lastvisit,
		  'thismessage',$thisseen,'thisvisit',$thisvisit,
		  'timestamp',$time,'wantnotice',$Cookies{'wantnotice'});
	}
}

sub Search {
	&Header("$boardname - Search",$MessageHeaderFile);
	&Header2;
	print "<H1 ALIGN=CENTER>Message Index ";
	print "Keyword Search</H1>\n";
	print "<P>Use the form below to search for specific messages. ";
	print "You can search either for messages containing a certain keyword ";
	print "or keywords, or for messages posted by a specific individual. ";
	print "(All searches are based on partial-string matches ";
	print "and are case-insensitive.)</P>\n";
	print "<FORM METHOD=POST ACTION=\"$cgiurl$BBSquery";
	print "index\"$BBStargetidx>\n";
	print "<CENTER>";
	unless ($ArchiveOnly) {
		print "<P>Search messages posted or modified ";
		print "within the last <SELECT NAME=\"ListTime\"><OPTION";
		if ($FORM{'ListTime'} eq "Twelve Hours") {
			print " SELECTED";
		}
		print ">Twelve Hours <OPTION";
		if ($FORM{'ListTime'} eq "Day") {
			print " SELECTED";
		}
		print ">Day <OPTION";
		if ($FORM{'ListTime'} eq "Two Days") {
			print " SELECTED";
		}
		print ">Two Days<OPTION";
		if ($FORM{'ListTime'} eq "Week") {
			print " SELECTED";
		}
		print ">Week<OPTION";
		if ($FORM{'ListTime'} eq "Two Weeks") {
			print " SELECTED";
		}
		print ">Two Weeks<OPTION";
		if ($FORM{'ListTime'} eq "Month") {
			print " SELECTED";
		}
		print ">Month<OPTION";
		if ($FORM{'ListTime'} eq "Several Eons") {
			print " SELECTED";
		}
		print ">Several Eons</SELECT>\n";
	}
	print "<P>Search for:\n",
	  "<P><INPUT TYPE=RADIO NAME=\"KeySearch\" ",
	  "VALUE=\"Yes\" CHECKED> Messages containing <SELECT ",
	  "NAME=\"Boolean\"><OPTION SELECTED>Any",
	  "<OPTION>All</SELECT> of the following keywords:",
	  "<BR><INPUT TYPE=TEXT NAME=\"Keywords\" ",
	  "SIZE=50>\n",
	  "<P><INPUT TYPE=RADIO NAME=\"KeySearch\" ",
	  "VALUE=\"Author\"> Messages posted by: <INPUT TYPE=TEXT ",
	  "NAME=\"Author\" SIZE=25></P>\n",
	  "<P><INPUT TYPE=SUBMIT VALUE=\"Search ",
	  "Messages\"></CENTER></P></FORM>\n";
	&Footer($MessageFooterFile,"credits");
}

sub Reconfigure {
	&Header("$boardname - Configuration",$MessageHeaderFile);
	&Header2;
	print "<H1 ALIGN=CENTER>Message Index ";
	print "Display Configuration</H1>\n";
	print "<P>Use the form below to select ",
	  "the manner in which you wish the ",
	  "messages in the index to be displayed. ";
	if ($UseCookies) {
		print "(If your browser supports and is set to accept ";
		print "&quot;cookies,&quot; your preferences will be ";
		print "remembered the next time you visit!)</P>\n";
	}
	else {
		print "(Note that since this board is not set to ";
		print "utilize &quot;cookies,&quot; your preferences ";
		print "will not be remembered the next time you ";
		print "visit.)</P>\n";
	}
	print "<FORM METHOD=POST ACTION=\"$cgiurl$BBSquery";
	print "index\"$BBStargetidx>\n";
	print "<INPUT TYPE=HIDDEN NAME=\"KeySearch\" ";
	print "VALUE=\"No\">\n";
	print "<CENTER>";
	unless ($ArchiveOnly) {
		print "<P>List messages posted or modified within the last <SELECT ";
		print "NAME=\"ListTime\"><OPTION";
		if ($FORM{'ListTime'} eq "Twelve Hours") {
			print " SELECTED";
		}
		print ">Twelve Hours <OPTION";
		if ($FORM{'ListTime'} eq "Day") {
			print " SELECTED";
		}
		print ">Day <OPTION";
		if ($FORM{'ListTime'} eq "Two Days") {
			print " SELECTED";
		}
		print ">Two Days<OPTION";
		if ($FORM{'ListTime'} eq "Week") {
			print " SELECTED";
		}
		print ">Week<OPTION";
		if ($FORM{'ListTime'} eq "Two Weeks") {
			print " SELECTED";
		}
		print ">Two Weeks<OPTION";
		if ($FORM{'ListTime'} eq "Month") {
			print " SELECTED";
		}
		print ">Month<OPTION";
		if ($FORM{'ListTime'} eq "Several Eons") {
			print " SELECTED";
		}
		print ">Several Eons</SELECT>\n";
	}
	print "<P>List messages <SELECT NAME=\"ListType\"><OPTION";
	if ($FORM{'ListType'} eq "Chronologically") {
		print " SELECTED";
	}
	print ">Chronologically<OPTION";
	if ($FORM{'ListType'} eq "Chronologically, Reversed") {
		print " SELECTED";
	}
	print ">Chronologically, Reversed<OPTION";
	if ($FORM{'ListType'} eq "By Threads") {
		print " SELECTED";
	}
	print ">By Threads<OPTION";
	if ($FORM{'ListType'} eq "By Threads, Reversed") {
		print " SELECTED";
	}
	print ">By Threads, Reversed<OPTION";
	if ($FORM{'ListType'} eq "By Threads, Mixed") {
		print " SELECTED";
	}
	print ">By Threads, Mixed<OPTION";
	if ($FORM{'ListType'} eq "Compressed") {
		print " SELECTED";
	}
	print ">Compressed<OPTION";
	if ($FORM{'ListType'} eq "Compressed, Reversed") {
		print " SELECTED";
	}
	print ">Compressed, Reversed<OPTION";
	if ($FORM{'ListType'} eq "Guestbook-Style") {
		print " SELECTED";
	}
	print ">Guestbook-Style<OPTION";
	if ($FORM{'ListType'} eq "Guestbook-Style, Reversed") {
		print " SELECTED";
	}
	print ">Guestbook-Style, Reversed<OPTION";
	if ($FORM{'ListType'} eq "Guestbook-Style, Threaded") {
		print " SELECTED";
	}
	print ">Guestbook-Style, Threaded<OPTION";
	if ($FORM{'ListType'} eq "Guestbook-Style, Threaded, Reversed") {
		print " SELECTED";
	}
	print ">Guestbook-Style, Threaded, Reversed</SELECT></CENTER>\n",
	  "<P><EM>$text{'5000'}</EM>\n",
	  "<P><CENTER><INPUT TYPE=SUBMIT VALUE=\"View Message ",
	  "Index\"></CENTER></P></FORM>\n";
	&Footer($MessageFooterFile,"credits");
}

sub UpdateAddressList {
	unless ($email) {
		&Error("9300","9301");
	}
	unless (-w "$dir") { &Error("9400","9401"); }
	&LockOpen (LIST,"$dir/addresses.txt");
	@list = <LIST>;
	$listcheck = 0;
	seek (LIST, 0, 0);
	foreach $address (@list) {
		if ($address =~ /$email/i) {
			if ($FORM{'action'} eq "delete") {
				&Error("9850","9851");
				$listcheck = 1;
			}
			else {
				&Error("9700","9701");
				print LIST "$address";
				$listcheck = 1;
			}
		}
		else {
			print LIST "$address";
		}
	}
	if ($listcheck < 1) {
		if ($FORM{'action'} eq "delete") {
			&Error("9750","9751");
		}
		else {
			&Error("9800","9801");
			print LIST "$email\n";
		}
	}
	truncate (LIST, tell(LIST));
	&LockClose (LIST,"$dir/addresses.txt");
	&Footer($MessageFooterFile,"return");
}

sub Error {
	local ($error_title, $error_text) = @_;
	&Header($text{$error_title},$MessageHeaderFile);
	&Header2;
	print "<H1 ALIGN=CENTER>";
	print "$text{$error_title}</H1>\n";
	print "<P>$text{$error_text} $text{'9999'}</P>\n";
	return unless ($error_title < 9700);
	&Footer($MessageFooterFile,"return");
}

sub Header {
	local ($header_title, $header_file) = @_;
	print "<HTML><HEAD><TITLE>$header_title</TITLE>\n";
	if ($HeadLinesFile) {
		open (HEADLN,"$HeadLinesFile");
		@headln = <HEADLN>;
		close (HEADLN);
		foreach $line (@headln) {
			print "$line";
		}
	}
	print "</HEAD><BODY $bodyspec>\n";
	if ($header_file) {
		open (HEADER,"$header_file");
		@header = <HEADER>;
		close (HEADER);
		foreach $line (@header) {
			if ($line =~ /<!--InsertAdvert\s*(.*)-->/i) {
				&insertadvert($1);
			}
			else {
				print "$line";
			}
		}
	}
}

sub Header2 {
	unless ($UseFrames) {
		$navbar .= "<P><CENTER>";
		$navbar .= "<TABLE BORDER CELLPADDING=6>";
		$navbar .= "<TR><TH>| <A HREF=\"$cgiurl$BBSquery\" TARGET=_self>";
		$navbar .= "$text{'0004'}</A> |";
		$navbar .= "</TH></TR></TABLE></CENTER></P>\n";
		print "$navbar";
		if ($printboardname) {
			print "<P ALIGN=CENTER><BIG><STRONG>";
			print "$boardname</STRONG></BIG></P>\n";
		}
	}
}

sub Footer {
	local ($footer_file,$footer_type) = @_;
	if ($navbar) { print "$navbar"; }
	if ($PrintDeleteButton) {
		print "<P><CENTER>",
		  "<FORM METHOD=POST ACTION=\"$cgiurl$BBSquery",
		  "delete\"$BBStarget>\n",
		  "<INPUT TYPE=HIDDEN NAME=\"password\" ",
		  "VALUE=\"$oldpassword\">\n",
		  "<INPUT TYPE=HIDDEN NAME=\"delete\" ",
		  "VALUE=\"$messagenumber\">\n",
		  "<INPUT TYPE=SUBMIT VALUE=\"Delete This Message\"> ",
		  "Password: <INPUT TYPE=PASSWORD NAME=\"newpassword\" ",
		  "SIZE=15>\n</FORM></CENTER></P>\n";
	}
	if ($footer_type eq "credits") {
		print "<P ALIGN=CENTER><SMALL><EM>$boardname ";
		print "is maintained with <STRONG>";
		print "<A HREF=\"http://awsd.com/scripts/webbbs/\" ";
		print "TARGET=_top>";
		print "WebBBS $version</A></STRONG>.</EM></SMALL></P>\n";
	}
	if ($footer_file) {
		open (FOOTER,"$footer_file");
		@footer = <FOOTER>;
		close (FOOTER);
		foreach $line (@footer) {
			if ($line =~ /<!--InsertAdvert\s*(.*)-->/i) {
				&insertadvert($1);
			}
			else {
				print "$line";
			}
		}
	}
	print "</BODY></HTML>\n";
	reset 'A-Za-z';
	exit;
}

sub LockOpen {
	local(*FILE,$lockfilename) = @_;
	local($TrysLeft) = 100;
	unless (-e "$lockfilename") {
		open (FILE,">$lockfilename");
		print FILE "\n";
		close (FILE);
	}
	if ($UseLocking) {
		open (FILE,"+<$lockfilename") || &Error("9400","9401");
		flock(FILE,2) || &Error("9410","9411");
	}
	else {
		if ((-e "$lockfilename.lok") && ((stat("$lockfilename.lok"))[9]+30<$time)) {
			unlink ("$lockfilename.lok");
		}
		while ($TrysLeft--) {
			if (-e "$lockfilename.lok") {
				select(undef,undef,undef,0.01);
			}
			else {
				open (LOCKFILE,">$lockfilename.lok");
				print LOCKFILE "\n";
				close (LOCKFILE);
				last;
			}
		}
		if ($TrysLeft >= 0) {
			open (FILE,"+<$lockfilename") || &Error("9400","9401");
		}
		else {
			&Error("9400","9401");
		}
	}
}

sub LockClose {
	local(*FILE,$lockfilename) = @_;
	close (FILE);
	unlink ("$lockfilename.lok");
}

sub Rebuild_Database {
	unless ($rebuildflag) {
		$messagecount = 0;
		opendir (MESSAGES,$dir);
		@messagecount = readdir(MESSAGES);
		closedir (MESSAGES);
		foreach $message (@messagecount) {
			unless (($message =~ /\.tmp$/) || ($message == 0)) {
				$messagecount ++;
				if ($message > $lastmessage) {
					$rebuildflag = 1;
				}
			}
		}
	}
	unless (($messagecount == @sortedmessages) && !($rebuildflag)) {
		@sortedmessages = sort {$a<=>$b} @messagecount;
		foreach $message (@sortedmessages) {
			next if (($message =~ /\.tmp$/) || ($message == 0));
			$timestamp{$message} = (stat("$dir/$message"))[9];
			next if ($subject{$message} && $poster{$message}
			  && (($time-$timestamp{$message})>3600));
			&ResetMessageData;
			unless ($subject{$message}) {
				unlink ("$dir/$message");
			}
		}
	}
	&LockOpen (INDEX,"$dir/messages.idx");
	seek (INDEX,0,0);
	foreach $message (@sortedmessages) {
		next if (($message =~ /\.tmp$/) || ($message == 0));
		next unless ($subject{$message});
		foreach $key
		  ($message,$timestamp{$message},$subject{$message},
		  $poster{$message},$date{$message},$previous{$message},
		  $next{$message},$count{$message},$admin{$message},
		  $ipaddress{$message}) {
			$key =~ s/\|/ /g;
			print INDEX "$key|";
		}
		print INDEX "\n";
	}
	truncate (INDEX, tell(INDEX));
	&LockClose (INDEX,"$dir/messages.idx");
}

sub ResetMessageData {
	$timestamp{$message} = (stat("$dir/$message"))[9];
	$age{$message} = (($time-$timestamp)/86400);
	open (FILE,"$dir/$message");
	@lines = <FILE>;
	close(FILE);
	foreach $line (@lines) {
		chop $line;
		$line =~ s/\|/ /;
		if ($line =~ /^SUBJECT>(.*)/i) {
			$subject{$message} = $1;
		}
		if ($line =~ /^ADMIN>AdminPost/i) {
			$admin{$message} = "AdminPost";
		}
		elsif ($line =~ /^POSTER>(.*)/i) {
			$poster{$message} = $1;
		}
		elsif ($line =~ /^DATE>(.*)/i) {
			$date{$message} = $1;
		}
		elsif ($line =~ /^IP_ADDRESS>(.*)/i) {
			$ipaddress{$message} = $1;
		}
		elsif ($line =~ /^PREVIOUS>(.*)/i) {
			$previous{$message} = $1;
		}
		elsif ($line =~ /^NEXT>(.*)/i) {
			$next{$message} = $1; last;
		}
	}
	unless ($date{$message} =~ /^\d*$/) {
		$date{$message} = $timestamp{$message};
	}
}

1;
